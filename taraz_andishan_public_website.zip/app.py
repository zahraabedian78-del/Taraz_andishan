import os, sqlite3, csv, io
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, jsonify, Response, flash
app=Flask(__name__)
app.secret_key=os.environ.get("SECRET_KEY","taraz-andishan-demo-key")
DB=os.environ.get("DATABASE_PATH","data/taraz.db")
os.makedirs(os.path.dirname(DB) or ".",exist_ok=True)
MODULES={
 "purchases":("خرید",["تاریخ","شرح کالا/خدمت","تأمین‌کننده","مبلغ (تومان)","وضعیت"],["date","title","party","amount","status"]),
 "sales":("فروش",["تاریخ","شرح کالا/خدمت","مشتری","مبلغ (تومان)","وضعیت"],["date","title","party","amount","status"]),
 "inventory":("انبار",["نام کالا","کد کالا","موجودی","حداقل موجودی","واحد"],["title","code","qty","minimum","unit"]),
 "finance":("امور مالی",["تاریخ","نوع تراکنش","شرح","مبلغ (تومان)","دسته‌بندی"],["date","kind","title","amount","category"]),
 "risks":("مدیریت ریسک",["عنوان ریسک","حوزه","احتمال (۱ تا ۵)","اثر (۱ تا ۵)","اقدام کنترلی"],["title","area","probability","impact","control"]),
 "users":("کاربران",["نام","سمت","ایمیل","شماره تماس"],["name","role","email","phone"])
}
def conn():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init():
 with conn() as c:
  for key,(label,heads,fields) in MODULES.items():
   cols=",".join(f+" TEXT" for f in fields)
   c.execute("CREATE TABLE IF NOT EXISTS "+key+" (id INTEGER PRIMARY KEY AUTOINCREMENT,"+cols+", created_at TEXT)")
init()
@app.route("/")
def home():
 with conn() as c:
  counts={k:c.execute("SELECT COUNT(*) FROM "+k).fetchone()[0] for k in MODULES}
  sums={}
  for k in ("purchases","sales","finance"):
   sums[k]=c.execute("SELECT COALESCE(SUM(CAST(REPLACE(amount,',','') AS REAL)),0) FROM "+k).fetchone()[0]
  recent={k:c.execute("SELECT * FROM "+k+" ORDER BY id DESC LIMIT 5").fetchall() for k in ("purchases","sales","risks")}
  low=c.execute("SELECT * FROM inventory WHERE CAST(qty AS REAL)<=CAST(minimum AS REAL) AND qty<>''").fetchall()
  risks=c.execute("SELECT * FROM risks ORDER BY (CAST(probability AS INTEGER)*CAST(impact AS INTEGER)) DESC LIMIT 5").fetchall()
 return render_template("index.html",modules=MODULES,counts=counts,sums=sums,recent=recent,low=low,risks=risks)
@app.route("/<module>",methods=["GET","POST"])
def listing(module):
 if module not in MODULES:return "یافت نشد",404
 label,heads,fields=MODULES[module]
 if request.method=="POST":
  vals=[request.form.get(f,"").strip() for f in fields]
  with conn() as c:c.execute("INSERT INTO "+module+" ("+",".join(fields)+",created_at) VALUES ("+",".join("?" for _ in fields)+",?)",vals+[datetime.now().isoformat(timespec="seconds")])
  flash("اطلاعات با موفقیت ثبت شد.");return redirect(url_for("listing",module=module))
 q=request.args.get("q","").strip()
 with conn() as c:
  if q:
   where=" OR ".join("CAST("+f+" AS TEXT) LIKE ?" for f in fields)
   rows=c.execute("SELECT * FROM "+module+" WHERE "+where+" ORDER BY id DESC",["%"+q+"%"]*len(fields)).fetchall()
  else:rows=c.execute("SELECT * FROM "+module+" ORDER BY id DESC").fetchall()
 return render_template("module.html",module=module,label=label,heads=heads,fields=fields,rows=rows,q=q)
@app.post("/delete/<module>/<int:item_id>")
def delete(module,item_id):
 if module not in MODULES:return "یافت نشد",404
 with conn() as c:c.execute("DELETE FROM "+module+" WHERE id=?",(item_id,))
 flash("رکورد حذف شد.");return redirect(url_for("listing",module=module))
@app.route("/export/<module>")
def export(module):
 if module not in MODULES:return "یافت نشد",404
 label,heads,fields=MODULES[module]
 with conn() as c:rows=c.execute("SELECT "+",".join(fields)+" FROM "+module+" ORDER BY id DESC").fetchall()
 out=io.StringIO();w=csv.writer(out);w.writerow(heads)
 for r in rows:w.writerow([r[f] for f in fields])
 return Response("\ufeff"+out.getvalue(),mimetype="text/csv; charset=utf-8",headers={"Content-Disposition":"attachment; filename="+module+".csv"})
@app.get("/health")
def health():return jsonify(status="ok")
if __name__=="__main__":app.run(host="0.0.0.0",port=int(os.environ.get("PORT",5000)))
